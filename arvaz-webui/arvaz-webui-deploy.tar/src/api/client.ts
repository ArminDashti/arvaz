import { clearToken, getToken } from '@/lib/auth'

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers)
  if (!headers.has('Content-Type') && init?.body && !(init.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json')
  }
  const token = getToken()
  if (token) headers.set('Authorization', `Bearer ${token}`)

  const res = await fetch(path, { ...init, headers })
  if (res.status === 401) {
    clearToken()
    if (!path.includes('/auth/login')) {
      window.location.href = '/login'
    }
    throw new Error('Unauthorized')
  }
  if (!res.ok) {
    throw new Error(`${res.status} ${res.statusText}`)
  }
  return (await res.json()) as T
}

export const api = {
  login: (username: string, password: string) =>
    requestJson<{ token: string; username: string }>('/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  dashboard: () => requestJson<Record<string, unknown>>('/api/v1/dashboard'),
  server: () => requestJson<Record<string, unknown>>('/api/v1/server'),
  monitoring: () => requestJson<Record<string, unknown>>('/api/v1/monitoring'),
  dockerOverview: () => requestJson<Record<string, unknown>>('/api/v1/docker/overview'),
  dockerImages: () => requestJson<{ images: DockerImage[]; error?: string }>('/api/v1/docker/images'),
  dockerContainers: () => requestJson<{ containers: DockerContainer[]; error?: string }>('/api/v1/docker/containers'),
  directories: (path = '') => requestJson<{ entries: DirectoryEntry[]; path: string; error?: string }>(`/api/v1/directories?path=${encodeURIComponent(path)}`),
  mkdir: (path: string, name: string) =>
    requestJson<{ ok: boolean }>('/api/v1/directories/mkdir', { method: 'POST', body: JSON.stringify({ path, name }) }),
  upload: (path: string, file: File) => {
    const form = new FormData()
    form.append('path', path)
    form.append('file', file)
    return requestJson<{ ok: boolean }>('/api/v1/directories/upload', { method: 'POST', body: form })
  },
  deletePath: (path: string) =>
    requestJson<{ ok: boolean }>(`/api/v1/directories?path=${encodeURIComponent(path)}`, { method: 'DELETE' }),
  softetherOverview: () => requestJson<{ overview: Record<string, unknown>; onlineCount: number; error?: string }>('/api/v1/softether/overview'),
  softetherSessions: () => requestJson<{ sessions: SoftEtherSession[]; error?: string }>('/api/v1/softether/sessions'),
  softetherUsers: () => requestJson<{ users: SoftEtherUser[]; error?: string }>('/api/v1/softether/users'),
  softetherLogs: () => requestJson<{ logs: SoftEtherLog[]; error?: string }>('/api/v1/softether/users/logs'),
  softetherStats: () => requestJson<{ stats: SoftEtherStats; error?: string }>('/api/v1/softether/stats'),
}

export type DockerImage = { id: string; tags: string[]; sizeBytes: number; createdAt: string }
export type DockerContainer = {
  containerName: string
  image: string
  state: string
  uptimeSeconds: number
  cpuPercent: number
  memoryBytes: number
  stackName: string
}
export type DirectoryEntry = {
  name: string
  path: string
  isDir: boolean
  sizeBytes: number
  createdAt: string
  modifiedAt: string
}
export type SoftEtherSession = {
  username: string
  clientIp: string
  asn: string | null
  downloadBytes: number
  uploadBytes: number
  sessionDurationSeconds: number
  connectedAt: string | null
}
export type SoftEtherUser = {
  username: string
  downloadBytes: number
  uploadBytes: number
  usageDurationSeconds: number
  connectedIpCount: number
}
export type SoftEtherLog = {
  username: string
  clientIp: string
  asn: string | null
  connectedAt: string
  disconnectedAt: string | null
  downloadBytes: number
  uploadBytes: number
  durationSeconds: number
}
export type SoftEtherStats = {
  onlineCount: number
  uniqueUsers: number
  totalDownloadBytes: number
  totalUploadBytes: number
  topUsers: SoftEtherUser[]
}
