<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api, type DockerImage } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDateTime } from '@/lib/utils'

const images = ref<DockerImage[]>([])
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    const res = await api.dockerImages()
    images.value = res.images ?? []
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 8000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <Card>
    <CardHeader><CardTitle>Docker images</CardTitle></CardHeader>
    <CardContent>
      <p v-if="error" class="mb-3 text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Tags</TableHead>
            <TableHead>Size</TableHead>
            <TableHead>Created</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-if="images.length === 0"><TableCell colspan="4" class="text-muted-foreground">No images</TableCell></TableRow>
          <TableRow v-for="img in images" :key="img.id">
            <TableCell class="font-mono text-xs">{{ img.id }}</TableCell>
            <TableCell>{{ (img.tags || []).join(', ') }}</TableCell>
            <TableCell>{{ formatBytes(img.sizeBytes) }}</TableCell>
            <TableCell>{{ formatDateTime(img.createdAt) }}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
