<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api, type DockerContainer } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDuration, formatPercent } from '@/lib/utils'

const containers = ref<DockerContainer[]>([])
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    const res = await api.dockerContainers()
    containers.value = res.containers ?? []
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 8000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <Card>
    <CardHeader><CardTitle>Docker containers</CardTitle></CardHeader>
    <CardContent>
      <p v-if="error" class="mb-3 text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Container</TableHead>
            <TableHead>Image</TableHead>
            <TableHead>State</TableHead>
            <TableHead>Uptime</TableHead>
            <TableHead>CPU</TableHead>
            <TableHead>Memory</TableHead>
            <TableHead>Stack</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-if="containers.length === 0"><TableCell colspan="7" class="text-muted-foreground">No containers</TableCell></TableRow>
          <TableRow v-for="c in containers" :key="c.containerName">
            <TableCell>{{ c.containerName }}</TableCell>
            <TableCell class="max-w-[180px] truncate">{{ c.image }}</TableCell>
            <TableCell>{{ c.state }}</TableCell>
            <TableCell>{{ formatDuration(c.uptimeSeconds) }}</TableCell>
            <TableCell>{{ formatPercent(c.cpuPercent) }}</TableCell>
            <TableCell>{{ formatBytes(c.memoryBytes) }}</TableCell>
            <TableCell>{{ c.stackName }}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
