<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { api, type SoftEtherStats } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDuration } from '@/lib/utils'

const stats = ref<SoftEtherStats | null>(null)
const error = ref('')

async function load() {
  try {
    const res = await api.softetherStats()
    stats.value = res.stats
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <p v-if="error" class="text-sm text-destructive">{{ error }}</p>
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card><CardHeader><CardTitle>Online</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ stats?.onlineCount ?? '—' }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Unique users</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ stats?.uniqueUsers ?? '—' }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Total download</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatBytes(stats?.totalDownloadBytes) }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Total upload</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatBytes(stats?.totalUploadBytes) }}</CardContent></Card>
    </div>
    <Card>
      <CardHeader><CardTitle>Top users by traffic</CardTitle></CardHeader>
      <CardContent>
        <Table>
          <TableHeader><TableRow><TableHead>Username</TableHead><TableHead>Download</TableHead><TableHead>Upload</TableHead><TableHead>Duration</TableHead></TableRow></TableHeader>
          <TableBody>
            <TableRow v-for="u in stats?.topUsers || []" :key="u.username">
              <TableCell>{{ u.username }}</TableCell>
              <TableCell>{{ formatBytes(u.downloadBytes) }}</TableCell>
              <TableCell>{{ formatBytes(u.uploadBytes) }}</TableCell>
              <TableCell>{{ formatDuration(u.usageDurationSeconds) }}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  </div>
</template>
