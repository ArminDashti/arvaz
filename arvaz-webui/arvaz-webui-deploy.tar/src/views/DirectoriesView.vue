<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { api, type DirectoryEntry } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDateTime } from '@/lib/utils'

const currentPath = ref('')
const entries = ref<DirectoryEntry[]>([])
const error = ref('')
const newFolder = ref('')
const busy = ref(false)

async function load(path = currentPath.value) {
  try {
    const res = await api.directories(path)
    entries.value = res.entries ?? []
    currentPath.value = res.path || ''
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

function openEntry(entry: DirectoryEntry) {
  if (entry.isDir) load(entry.path)
}

function goUp() {
  const parts = currentPath.value.split('/').filter(Boolean)
  parts.pop()
  load(parts.join('/'))
}

async function createFolder() {
  if (!newFolder.value.trim()) return
  busy.value = true
  try {
    await api.mkdir(currentPath.value, newFolder.value.trim())
    newFolder.value = ''
    await load()
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to create folder'
  } finally {
    busy.value = false
  }
}

async function onUpload(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  busy.value = true
  try {
    await api.upload(currentPath.value, file)
    await load()
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Upload failed'
  } finally {
    busy.value = false
    input.value = ''
  }
}

async function removeEntry(entry: DirectoryEntry) {
  if (!confirm(`Delete ${entry.name}?`)) return
  busy.value = true
  try {
    await api.deletePath(entry.path)
    await load()
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Delete failed'
  } finally {
    busy.value = false
  }
}

onMounted(() => load(''))
</script>

<template>
  <Card>
    <CardHeader><CardTitle>Directories</CardTitle></CardHeader>
    <CardContent class="space-y-4">
      <p class="text-sm text-muted-foreground">Path: /{{ currentPath || '(root)' }}</p>
      <div class="flex flex-wrap gap-2">
        <button class="theme-toggle" :disabled="!currentPath || busy" @click="goUp">Up</button>
        <input v-model="newFolder" class="field-input max-w-xs" placeholder="New folder name" />
        <button class="theme-toggle" :disabled="busy" @click="createFolder">Create folder</button>
        <label class="theme-toggle cursor-pointer">
          Upload<input type="file" class="hidden" :disabled="busy" @change="onUpload" />
        </label>
      </div>
      <p v-if="error" class="text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Size</TableHead>
            <TableHead>Created</TableHead>
            <TableHead>Modified</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-for="entry in entries" :key="entry.path">
            <TableCell>
              <button class="text-left hover:underline" @click="openEntry(entry)">
                {{ entry.isDir ? '📁' : '📄' }} {{ entry.name }}
              </button>
            </TableCell>
            <TableCell>{{ formatBytes(entry.sizeBytes) }}</TableCell>
            <TableCell>{{ formatDateTime(entry.createdAt) }}</TableCell>
            <TableCell>{{ formatDateTime(entry.modifiedAt) }}</TableCell>
            <TableCell><button class="text-destructive text-sm" :disabled="busy" @click="removeEntry(entry)">Delete</button></TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
