<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { api, type SoftEtherUser } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDuration } from '@/lib/utils'

const users = ref<SoftEtherUser[]>([])
const error = ref('')

async function load() {
  try {
    const res = await api.softetherUsers()
    users.value = res.users ?? []
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(load)
</script>

<template>
  <Card>
    <CardHeader><CardTitle>SoftEther users</CardTitle></CardHeader>
    <CardContent>
      <p v-if="error" class="mb-3 text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Username</TableHead>
            <TableHead>Download</TableHead>
            <TableHead>Upload</TableHead>
            <TableHead>Duration</TableHead>
            <TableHead>Connected IPs</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-for="u in users" :key="u.username">
            <TableCell>{{ u.username }}</TableCell>
            <TableCell>{{ formatBytes(u.downloadBytes) }}</TableCell>
            <TableCell>{{ formatBytes(u.uploadBytes) }}</TableCell>
            <TableCell>{{ formatDuration(u.usageDurationSeconds) }}</TableCell>
            <TableCell>{{ u.connectedIpCount }}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
