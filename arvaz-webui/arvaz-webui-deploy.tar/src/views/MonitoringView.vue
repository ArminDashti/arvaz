<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { api } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import LineChart from '@/components/LineChart.vue'
import { formatBytes, formatPercent } from '@/lib/utils'

const data = ref<Record<string, unknown> | null>(null)
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    data.value = await api.monitoring()
    error.value = ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

const cpuChart = computed(() => {
  const series = (data.value?.cpuSeries as { timestamp: string; value: number }[]) || []
  return {
    labels: series.map((p) => new Date(p.timestamp).toLocaleTimeString()),
    datasets: [{ label: 'CPU %', data: series.map((p) => p.value), color: '#5ec8ff' }],
  }
})

const memoryChart = computed(() => {
  const series = (data.value?.memorySeries as { timestamp: string; value: number }[]) || []
  return {
    labels: series.map((p) => new Date(p.timestamp).toLocaleTimeString()),
    datasets: [{ label: 'Memory %', data: series.map((p) => p.value), color: '#8b5cf6' }],
  }
})

onMounted(() => { load(); timer = window.setInterval(load, 3000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <div class="space-y-4">
    <p v-if="error" class="text-sm text-destructive">{{ error }}</p>
    <div class="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader><CardTitle>CPU {{ formatPercent(data?.cpuPercent as number) }}</CardTitle></CardHeader>
        <CardContent><LineChart :labels="cpuChart.labels" :datasets="cpuChart.datasets" /></CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Memory {{ formatPercent(data?.memoryUsedPercent as number) }}</CardTitle></CardHeader>
        <CardContent><LineChart :labels="memoryChart.labels" :datasets="memoryChart.datasets" /></CardContent>
      </Card>
    </div>
    <Card>
      <CardHeader><CardTitle>Apps (containers)</CardTitle></CardHeader>
      <CardContent>
        <Table>
          <TableHeader><TableRow><TableHead>Container</TableHead><TableHead>CPU</TableHead><TableHead>Memory</TableHead><TableHead>State</TableHead></TableRow></TableHeader>
          <TableBody>
            <TableRow v-for="app in (data?.apps as any[] || [])" :key="app.containerName">
              <TableCell>{{ app.containerName }}</TableCell>
              <TableCell>{{ formatPercent(app.cpuPercent) }}</TableCell>
              <TableCell>{{ formatBytes(app.memoryBytes) }}</TableCell>
              <TableCell>{{ app.state }}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  </div>
</template>
