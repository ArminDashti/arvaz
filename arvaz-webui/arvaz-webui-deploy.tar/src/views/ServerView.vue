<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatBps, formatDuration, formatPercent } from '@/lib/utils'

const data = ref<Record<string, unknown> | null>(null)
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    data.value = await api.server()
    error.value = ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 5000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <div class="space-y-4">
    <p v-if="error" class="text-sm text-destructive">{{ error }}</p>
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card><CardHeader><CardTitle>CPU</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatPercent(data?.cpuPercent as number) }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Memory</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatPercent(data?.memoryUsedPercent as number) }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Public IP</CardTitle></CardHeader><CardContent class="font-mono">{{ data?.publicIp || '—' }}</CardContent></Card>
      <Card><CardHeader><CardTitle>Uptime</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatDuration(data?.uptimeSeconds as number) }}</CardContent></Card>
    </div>
    <Card>
      <CardHeader><CardTitle>Network</CardTitle></CardHeader>
      <CardContent>
        <Table>
          <TableHeader><TableRow><TableHead>Interface</TableHead><TableHead>Addresses</TableHead><TableHead>Rx</TableHead><TableHead>Tx</TableHead></TableRow></TableHeader>
          <TableBody>
            <TableRow v-for="iface in (data?.network as any[] || [])" :key="iface.name">
              <TableCell>{{ iface.name }}</TableCell>
              <TableCell class="font-mono text-xs">{{ (iface.addresses || []).join(', ') || '—' }}</TableCell>
              <TableCell>{{ formatBytes(iface.bytesRecv) }}</TableCell>
              <TableCell>{{ formatBytes(iface.bytesSent) }}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
        <p class="mt-3 text-sm text-muted-foreground">Live: ↓ {{ formatBps(data?.bandwidthRxBps as number) }} · ↑ {{ formatBps(data?.bandwidthTxBps as number) }}</p>
      </CardContent>
    </Card>
    <Card>
      <CardHeader><CardTitle>Storage</CardTitle></CardHeader>
      <CardContent>
        <Table>
          <TableHeader><TableRow><TableHead>Mount</TableHead><TableHead>Type</TableHead><TableHead>Used</TableHead><TableHead>Total</TableHead><TableHead>Used %</TableHead></TableRow></TableHeader>
          <TableBody>
            <TableRow v-for="disk in (data?.disks as any[] || [])" :key="disk.mountPoint">
              <TableCell>{{ disk.mountPoint }}</TableCell>
              <TableCell>{{ disk.fstype || '—' }}</TableCell>
              <TableCell>{{ formatBytes(disk.usedBytes) }}</TableCell>
              <TableCell>{{ formatBytes(disk.totalBytes) }}</TableCell>
              <TableCell>{{ formatPercent(disk.usedPercent) }}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  </div>
</template>
