<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { api, type SoftEtherLog } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatDateTime, formatDuration } from '@/lib/utils'

const logs = ref<SoftEtherLog[]>([])
const error = ref('')

async function load() {
  try {
    const res = await api.softetherLogs()
    logs.value = res.logs ?? []
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(load)
</script>

<template>
  <Card>
    <CardHeader><CardTitle>SoftEther session logs</CardTitle></CardHeader>
    <CardContent>
      <p v-if="error" class="mb-3 text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Username</TableHead>
            <TableHead>IP</TableHead>
            <TableHead>ASN</TableHead>
            <TableHead>Connected</TableHead>
            <TableHead>Disconnected</TableHead>
            <TableHead>Duration</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-for="(log, i) in logs" :key="i">
            <TableCell>{{ log.username }}</TableCell>
            <TableCell>{{ log.clientIp || '—' }}</TableCell>
            <TableCell>{{ log.asn || '—' }}</TableCell>
            <TableCell>{{ formatDateTime(log.connectedAt) }}</TableCell>
            <TableCell>{{ formatDateTime(log.disconnectedAt) }}</TableCell>
            <TableCell>{{ formatDuration(log.durationSeconds) }}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
