<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const overview = ref<Record<string, unknown> | null>(null)
const onlineCount = ref(0)
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    const res = await api.softetherOverview()
    overview.value = res.overview
    onlineCount.value = res.onlineCount
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 8000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    <p v-if="error" class="text-sm text-destructive sm:col-span-full">{{ error }}</p>
    <Card><CardHeader><CardTitle>Hub</CardTitle></CardHeader><CardContent>{{ overview?.hubName || '—' }}</CardContent></Card>
    <Card><CardHeader><CardTitle>Container</CardTitle></CardHeader><CardContent>{{ overview?.container || '—' }}</CardContent></Card>
    <Card><CardHeader><CardTitle>Online users</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ onlineCount }}</CardContent></Card>
    <Card class="sm:col-span-full">
      <CardHeader><CardTitle>Hub status</CardTitle></CardHeader>
      <CardContent><pre class="overflow-auto text-xs whitespace-pre-wrap">{{ overview?.hubStatusRaw || '—' }}</pre></CardContent>
    </Card>
  </div>
</template>
