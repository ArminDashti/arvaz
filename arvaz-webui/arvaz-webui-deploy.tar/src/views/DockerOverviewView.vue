<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { formatBytes } from '@/lib/utils'

const data = ref<Record<string, unknown> | null>(null)
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    data.value = await api.dockerOverview()
    error.value = (data.value?.error as string) || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 8000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
    <p v-if="error" class="text-sm text-destructive sm:col-span-full">{{ error }}</p>
    <Card><CardHeader><CardTitle>Running</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ data?.runningCount ?? '—' }}</CardContent></Card>
    <Card><CardHeader><CardTitle>Stopped</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ data?.stoppedCount ?? '—' }}</CardContent></Card>
    <Card><CardHeader><CardTitle>Images</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ data?.imagesCount ?? '—' }}</CardContent></Card>
    <Card><CardHeader><CardTitle>Image size</CardTitle></CardHeader><CardContent class="text-2xl font-semibold">{{ formatBytes(data?.totalImageSizeBytes as number) }}</CardContent></Card>
  </div>
</template>
