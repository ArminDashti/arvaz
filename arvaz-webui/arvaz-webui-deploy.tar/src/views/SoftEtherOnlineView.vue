<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { api, type SoftEtherSession } from '@/api/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { formatBytes, formatDateTime } from '@/lib/utils'

const sessions = ref<SoftEtherSession[]>([])
const error = ref('')
let timer: number | undefined

async function load() {
  try {
    const res = await api.softetherSessions()
    sessions.value = res.sessions ?? []
    error.value = res.error || ''
  } catch (e) {
    error.value = e instanceof Error ? e.message : 'Failed to load'
  }
}

onMounted(() => { load(); timer = window.setInterval(load, 5000) })
onUnmounted(() => { if (timer) window.clearInterval(timer) })
</script>

<template>
  <Card>
    <CardHeader><CardTitle>SoftEther online users</CardTitle></CardHeader>
    <CardContent>
      <p v-if="error" class="mb-3 text-sm text-destructive">{{ error }}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Username</TableHead>
            <TableHead>Connected</TableHead>
            <TableHead>Download</TableHead>
            <TableHead>Upload</TableHead>
            <TableHead>IP</TableHead>
            <TableHead>ASN</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow v-if="sessions.length === 0"><TableCell colspan="6" class="text-muted-foreground">No online sessions</TableCell></TableRow>
          <TableRow v-for="(s, i) in sessions" :key="i">
            <TableCell>{{ s.username }}</TableCell>
            <TableCell>{{ formatDateTime(s.connectedAt) }}</TableCell>
            <TableCell>{{ formatBytes(s.downloadBytes) }}</TableCell>
            <TableCell>{{ formatBytes(s.uploadBytes) }}</TableCell>
            <TableCell>{{ s.clientIp || '—' }}</TableCell>
            <TableCell>{{ s.asn || '—' }}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </CardContent>
  </Card>
</template>
