<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { RouterLink, RouterView, useRouter } from 'vue-router'
import {
  applyTheme,
  cycleThemePreference,
  nextPreferenceLabel,
  PREFERENCE_LABELS,
  resolveEffectiveTheme,
  resolveThemePreference,
  subscribeSystemTheme,
  type ThemePreference,
} from '@/lib/theme'
import { clearToken } from '@/lib/auth'

const router = useRouter()
const preference = ref<ThemePreference>(resolveThemePreference())
let unsubscribe: (() => void) | undefined

onMounted(() => {
  applyTheme(resolveEffectiveTheme(preference.value))
  if (preference.value === 'system') {
    unsubscribe = subscribeSystemTheme(applyTheme)
  }
})

onUnmounted(() => {
  unsubscribe?.()
})

function handleThemeCycle() {
  preference.value = cycleThemePreference(preference.value)
  if (preference.value === 'system') {
    unsubscribe?.()
    unsubscribe = subscribeSystemTheme(applyTheme)
  } else {
    unsubscribe?.()
    unsubscribe = undefined
  }
}

function logout() {
  clearToken()
  router.push('/login')
}

const links = [
  { to: '/', label: 'Dashboard' },
  { to: '/docker', label: 'Docker' },
  { to: '/docker/containers', label: 'Containers' },
  { to: '/docker/images', label: 'Images' },
  { to: '/server', label: 'Server' },
  { to: '/directories', label: 'Directories' },
  { to: '/monitoring', label: 'Monitoring' },
  { to: '/softether', label: 'SoftEther' },
  { to: '/softether/users/online', label: 'SE Online' },
  { to: '/softether/users', label: 'SE Users' },
  { to: '/softether/users/logs', label: 'SE Logs' },
  { to: '/softether/stats', label: 'SE Stats' },
]
</script>

<template>
  <div class="app-shell">
    <header class="site-header">
      <div class="site-header-top">
        <RouterLink to="/" class="site-logo">Arvaz</RouterLink>
        <div class="site-header-actions">
          <button
            type="button"
            class="theme-toggle"
            :aria-label="`Theme: ${PREFERENCE_LABELS[preference]}. Next: ${nextPreferenceLabel(preference)}`"
            @click="handleThemeCycle"
          >
            {{ PREFERENCE_LABELS[preference] }}
          </button>
          <button type="button" class="theme-toggle" @click="logout">Logout</button>
        </div>
      </div>
      <nav class="site-nav" aria-label="Primary">
        <RouterLink
          v-for="link in links"
          :key="link.to"
          :to="link.to"
          class="site-nav-link"
          active-class="is-active"
        >
          {{ link.label }}
        </RouterLink>
      </nav>
    </header>

    <main class="site-main">
      <RouterView />
    </main>

    <footer class="site-footer">
      <a
        class="site-footer-github"
        href="https://github.com/ArminDashti"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Armin Dashti on GitHub"
      >
        <svg class="site-footer-github-icon" viewBox="0 0 16 16" width="22" height="22" aria-hidden="true">
          <path
            fill="currentColor"
            d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27s1.36.09 2 .27c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8z"
          />
        </svg>
      </a>
      <p class="site-footer-copy">© 2026 Dashti Technologies (Armin Dashti)</p>
      <span class="site-footer-spacer" aria-hidden="true" />
    </footer>
  </div>
</template>
