import { createApp } from 'vue'
import { registerSW } from 'virtual:pwa-register'
import App from './App.vue'
import router from './router'
import { applyTheme, resolveEffectiveTheme, resolveThemePreference } from './lib/theme'
import './style.css'

applyTheme(resolveEffectiveTheme(resolveThemePreference()))

registerSW({ immediate: true })

createApp(App).use(router).mount('#app')
