import { createRouter, createWebHistory } from 'vue-router'
import { isAuthenticated } from '@/lib/auth'
import AppShell from '@/components/AppShell.vue'
import LoginView from '@/views/LoginView.vue'
import DashboardView from '@/views/DashboardView.vue'
import DockerOverviewView from '@/views/DockerOverviewView.vue'
import DockerContainersView from '@/views/DockerContainersView.vue'
import DockerImagesView from '@/views/DockerImagesView.vue'
import ServerView from '@/views/ServerView.vue'
import DirectoriesView from '@/views/DirectoriesView.vue'
import MonitoringView from '@/views/MonitoringView.vue'
import SoftEtherOverviewView from '@/views/SoftEtherOverviewView.vue'
import SoftEtherOnlineView from '@/views/SoftEtherOnlineView.vue'
import SoftEtherUsersView from '@/views/SoftEtherUsersView.vue'
import SoftEtherLogsView from '@/views/SoftEtherLogsView.vue'
import SoftEtherStatsView from '@/views/SoftEtherStatsView.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', name: 'login', component: LoginView, meta: { public: true } },
    {
      path: '/',
      component: AppShell,
      children: [
        { path: '', name: 'dashboard', component: DashboardView },
        { path: 'docker', name: 'docker', component: DockerOverviewView },
        { path: 'docker/containers', name: 'docker-containers', component: DockerContainersView },
        { path: 'docker/images', name: 'docker-images', component: DockerImagesView },
        { path: 'server', name: 'server', component: ServerView },
        { path: 'directories', name: 'directories', component: DirectoriesView },
        { path: 'monitoring', name: 'monitoring', component: MonitoringView },
        { path: 'softether', name: 'softether', component: SoftEtherOverviewView },
        { path: 'softether/users/online', name: 'softether-online', component: SoftEtherOnlineView },
        { path: 'softether/users', name: 'softether-users', component: SoftEtherUsersView },
        { path: 'softether/users/logs', name: 'softether-logs', component: SoftEtherLogsView },
        { path: 'softether/stats', name: 'softether-stats', component: SoftEtherStatsView },
      ],
    },
  ],
})

router.beforeEach((to) => {
  if (to.meta.public) {
    if (to.path === '/login' && isAuthenticated()) return '/'
    return true
  }
  if (!isAuthenticated()) return '/login'
  return true
})

export default router
